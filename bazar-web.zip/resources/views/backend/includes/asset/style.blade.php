<!-- Favicon icon -->
<link rel="icon" type="image/png" sizes="16x16" href="{{ asset('/') }}backend/assets/images/favicon.png">
<!-- Custom CSS -->
<link rel="stylesheet" href="{{ asset('/') }}backend/dist/libs/toastr/toastr.min.css" />
<link rel="stylesheet" href="{{ asset('/') }}backend/dist/libs/jvectormap/jquery-jvectormap.css">
<!-- Custom CSS -->
{{--<link href="{{ asset('/') }}backend/dist/css/style.min.css" rel="stylesheet">--}}
<link href="{{ asset('/') }}backend/helper/helper.min.css" rel="stylesheet">
<link href="{{ asset('/') }}backend/dist/css/style.css" rel="stylesheet">

@stack('style')
