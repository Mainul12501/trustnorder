<meta name="keywords" content="sm technology, sm technology, sms, school management system, modern school management system">
<meta name="description" content="SM Technology SMS is a modern school management system.">

@stack('meta')
